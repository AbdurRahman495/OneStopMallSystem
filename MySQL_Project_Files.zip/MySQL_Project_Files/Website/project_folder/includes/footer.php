<footer>
    <p>&copy; 2024 Shopping Mall. All rights reserved.</p>
</footer>
</body>
</html>
