<?php
include('includes/header.php');
?>

<main>
    <h1>Welcome to the Shopping Mall</h1>
    <p>Browse and buy products online!</p>
</main>

<?php
include('includes/footer.php');
?>
